const fs = require('node:fs');
const path = require('node:path');
const { Resvg } = require('@resvg/resvg-js');

const root = path.resolve(__dirname, '..');
const output = path.join(root, 'out', 'msix-assets');
const source = fs.readFileSync(path.join(root, 'src', 'orbit-mark.svg'), 'utf8');
fs.mkdirSync(output, { recursive: true });

for (const [name, size] of [
  ['icon.png', 256],
  ['Square44x44Logo.png', 44],
  ['Square150x150Logo.png', 150]
]) {
  const image = new Resvg(source, { fitTo: { mode: 'width', value: size } }).render().asPng();
  fs.writeFileSync(path.join(output, name), image);
}

console.log(`Created Orbit's Store tile icons in ${output}`);
