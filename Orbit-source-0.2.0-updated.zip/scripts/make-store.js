const { spawnSync } = require('node:child_process');
const path = require('node:path');

if (process.platform !== 'win32') {
  console.error('The Orbit Store package can only be built on Windows 10/11 with the Windows SDK installed.');
  process.exit(1);
}

for (const key of ['ORBIT_STORE_PACKAGE_ID', 'ORBIT_STORE_PUBLISHER']) {
  if (!process.env[key]) {
    console.error(`Set ${key} using the app identity assigned in Partner Center before building.`);
    process.exit(1);
  }
}

const cli = require.resolve('@electron-forge/cli/dist/electron-forge.js');
const result = spawnSync(process.execPath, [cli, 'make', '--platform', 'win32', '--arch', 'x64'], {
  cwd: path.resolve(__dirname, '..'),
  stdio: 'inherit',
  env: { ...process.env, ORBIT_STORE_BUILD: '1' }
});

if (result.error) throw result.error;
process.exit(result.status ?? 1);
