## Orbit 0.2.0 preview release

This is an experimental release for Windows and Linux. The previous macOS downloads were unsigned and not notarized, and macOS may reject them as damaged. The macOS downloads have been withdrawn and are not supported.

Packages are built on native GitHub-hosted runners for Windows and Linux. Windows and Linux downloads are preview packages; Linux may require system libraries provided by the target distribution. Browser extensions, cross-device sync, and a password manager are not included.

Orbit has not received an independent security audit. Automated tests and scans do not certify browser security. The optional Ghostery-based content blocker uses third-party filter lists and can miss ads or trackers.
