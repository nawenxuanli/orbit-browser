const path = require('node:path');

const packagerConfig = {
    name: 'Orbit',
    appBundleId: 'studio.orbit.browser',
    asar: true,
    ignore: [/^\/outputs(?:\/|$)/, /^\/work(?:\/|$)/, /^\/out(?:\/|$)/],
    download: { cacheRoot: path.join(__dirname, 'work', 'electron-cache') }
};

// These settings are applied only when the release workflow has installed the
// owner's Developer ID certificate and App Store Connect API credentials.
if (process.env.CSC_NAME) {
  packagerConfig.osxSign = { identity: process.env.CSC_NAME };
  if (process.env.APPLE_API_KEY_PATH && process.env.APPLE_API_KEY_ID && process.env.APPLE_API_ISSUER) {
    packagerConfig.osxNotarize = {
      appleApiKey: process.env.APPLE_API_KEY_PATH,
      appleApiKeyId: process.env.APPLE_API_KEY_ID,
      appleApiIssuer: process.env.APPLE_API_ISSUER
    };
  }
}

const makers = [{ name: '@electron-forge/maker-zip' }];

// Only enable the Store maker in an explicitly requested Windows Store build.
// Partner Center assigns both values after the publisher reserves Orbit's name.
if (process.env.ORBIT_STORE_BUILD === '1') {
  const packageIdentity = process.env.ORBIT_STORE_PACKAGE_ID;
  const publisher = process.env.ORBIT_STORE_PUBLISHER;
  if (!packageIdentity || !publisher) {
    throw new Error('Set ORBIT_STORE_PACKAGE_ID and ORBIT_STORE_PUBLISHER from the reserved Partner Center app identity before building.');
  }
  makers.push({
    name: '@electron-forge/maker-msix',
    config: {
      packageName: 'Orbit',
      packageAssets: path.join(__dirname, 'out', 'msix-assets'),
      manifestVariables: {
        packageIdentity,
        publisher,
        packageDisplayName: 'Orbit',
        appDisplayName: 'Orbit',
        publisherDisplayName: 'Orbit Browser',
        packageDescription: 'An experimental, customizable desktop web browser.',
        packageVersion: `${require('./package.json').version}.0`,
        packageMinOSVersion: '10.0.19041.0',
        packageMaxOSVersionTested: '10.0.26100.0'
      }
    }
  });
}

module.exports = {
  packagerConfig,
  rebuildConfig: {},
  // The host runner creates its native ZIP. This keeps each OS build native,
  // which is required for signing and avoids fragile cross-platform packaging.
  makers
};
