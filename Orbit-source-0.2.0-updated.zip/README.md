# Orbit

Orbit is an experimental desktop browser MVP with an original visual identity. It uses the Chromium engine bundled with Electron and is not affiliated with Brave, Vivaldi, or their publishers.

Prebuilt release downloads are currently provided for Windows and Linux only.

## Architecture

- **Main process:** owns browser windows, tab WebContentsViews, navigation, local JSON persistence, and website permission prompts.
- **Browser chrome:** a local HTML/CSS/JS interface with a narrowly scoped preload bridge. It receives only named UI events and sends validated command names over IPC.
- **Websites:** each tab has its own WebContentsView with Chromium's normal site isolation, context isolation, renderer sandbox, Node integration disabled, and web security enabled. Popups become tabs. Searches and bare hostnames use HTTPS; explicitly entered HTTP addresses are allowed. Text searches use DuckDuckGo.
- **Data:** bookmarks, recent visit history, notes, downloads, web panels, saved permission choices, and preferences are stored separately for each profile in Orbit's Electron user-data folder. Private windows use non-persistent Electron sessions and do not write those items to disk. No telemetry is sent.
- **Content blocking:** the optional blocker uses the open-source [Ghostery Adblocker](https://github.com/ghostery/adblocker) with its bundled ads and tracking filter rules. The rules are downloaded from the provider on first activation and cached locally; Orbit sends no browsing history or page data to fetch them. The blocker is disabled by default.

## Run locally

Install Node.js 22.13 or later, then run:

```sh
npm install
npm start
```

To create a ZIP for your current operating system:

```sh
npm run make
```

Electron Forge creates the current platform's ZIP under `out/make`. Developers can build locally on supported Electron Forge platforms. The GitHub release workflow publishes Windows x64 and Linux x64 packages only.

### Microsoft Store preparation

The opt-in `npm run make:store` target and the manual **Build and validate Orbit MSIX** GitHub Actions workflow prepare a Windows x64 MSIX and run WACK on a Windows runner. The build requires the Package/Identity Name and Publisher assigned after reserving Orbit in Partner Center; set them as repository Actions variables `ORBIT_STORE_PACKAGE_ID` and `ORBIT_STORE_PUBLISHER`. The package maker is experimental. This workflow does not submit or publish the app, and a passing WACK report is not Store approval. See [`docs/MICROSOFT_STORE_SUBMISSION.md`](docs/MICROSOFT_STORE_SUBMISSION.md) for the current checklist and listing/privacy drafts.

## Downloads

Download the Windows x64 or Linux x64 ZIP from the [GitHub Releases page](https://github.com/nawenxuanli/orbit-browser/releases). Linux distributions may require system libraries. All builds remain experimental.

### macOS downloads withdrawn

The macOS ZIPs were unsigned and not notarized, and macOS may reject them as damaged. Do not use the old Mac downloads. Mac releases will return only after Orbit can be properly signed and notarized.

## Checks and security

Run `npm test` for local automated checks. GitHub Actions runs tests and a dependency audit on pushes and pull requests, plus scheduled CodeQL analysis. Run `npm start` to inspect browser features. Automated checks are not a security certification or an independent security audit.

## Current scope

Implemented: navigation and search, tabs with pinning and named groups, bookmarks, history with clear controls, downloads, local notes, four appearance themes, a hideable and reorderable toolbar, configurable shortcuts, per-request website permission prompts with optional remembered choices and a dashboard to review or clear them, separate profiles, private windows, and saved web panels that open in a side view. A web panel is an ordinary sandboxed Chromium view sharing the current profile's storage. Prebuilt release workflows target Windows x64 and Linux x64. macOS is not currently a supported download.

The optional blocker refreshes its Ghostery filter cache after seven days when the blocker is next activated. If refresh fails, it keeps the previous cached rules. It can still miss ads or trackers and does not include cosmetic page cleanup. Web panel sites depend on the network connection and site behavior. Orbit does not claim Brave/Vivaldi feature parity or privacy-audit certification. Browser extensions, cross-device sync, and a password manager are not implemented.

## Security notes

Electron and Chromium provide important isolation primitives, but Orbit has not had an independent security audit. Website permission requests are shown before access; the user can allow or deny once, or remember the choice for that site and permission in a regular profile. Private windows do not save those choices. Unhandled schemes are blocked. Automated checks do not prove security. See `SECURITY.md` for vulnerability reporting, and `THIRD_PARTY_NOTICES.md` for blocker attribution and license.
