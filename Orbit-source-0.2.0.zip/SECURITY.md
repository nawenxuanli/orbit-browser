# Security policy

Orbit is experimental browser software. It has not received an independent security audit, and automated checks do not establish that it is safe for sensitive browsing.

Please report suspected vulnerabilities privately through GitHub's **Report a vulnerability** feature on this repository. Include the affected version, steps to reproduce, and impact. Do not post working exploits in a public issue. The maintainers will acknowledge reports when able; no response-time guarantee is currently provided.

The project runs automated tests, dependency vulnerability checks, and CodeQL static analysis in GitHub Actions. These checks are useful but are not a substitute for a professional security review.

