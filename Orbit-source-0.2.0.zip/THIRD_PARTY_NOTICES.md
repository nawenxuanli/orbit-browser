# Third-party notices

## Ghostery Adblocker

Orbit includes `@ghostery/adblocker-electron` and its dependencies to provide optional content blocking.

- Source and project: https://github.com/ghostery/adblocker
- Package license: Mozilla Public License 2.0 (MPL-2.0)
- The bundled filter configuration is provided by the Ghostery Adblocker project. Filter rule sources and their licensing/attribution are maintained by that project.

Orbit is not affiliated with Ghostery. The blocker is disabled by default. When enabled, it downloads and locally caches the rules; it does not transmit browsing history or page contents.
