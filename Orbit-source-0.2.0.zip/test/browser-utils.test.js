const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeUrl, isBlockedTracker, isFilterCacheStale, calculateViewBounds } = require('../src/browser-utils');

test('keeps explicit HTTP and HTTPS addresses', () => {
  assert.equal(normalizeUrl('https://example.org/a'), 'https://example.org/a');
  assert.equal(normalizeUrl('http://localhost:3000'), 'http://localhost:3000');
});

test('adds HTTPS to host-like input', () => {
  assert.equal(normalizeUrl('example.org/path'), 'https://example.org/path');
});

test('sends search text to DuckDuckGo', () => {
  assert.equal(normalizeUrl('quiet browser'), 'https://duckduckgo.com/?q=quiet%20browser');
});

test('uses a safe default for empty input', () => {
  assert.equal(normalizeUrl('  '), 'https://duckduckgo.com');
});

test('matches known tracker hosts and their subdomains only', () => {
  assert.equal(isBlockedTracker('google-analytics.com'), true);
  assert.equal(isBlockedTracker('region.google-analytics.com'), true);
  assert.equal(isBlockedTracker('notgoogle-analytics.com'), false);
  assert.equal(isBlockedTracker('example.org'), false);
});

test('refreshes missing, invalid, or older-than-seven-day filter caches', () => {
  const now = 1_800_000_000_000;
  assert.equal(isFilterCacheStale(null, now), true);
  assert.equal(isFilterCacheStale({ updatedAt: Number.NaN }, now), true);
  assert.equal(isFilterCacheStale({ updatedAt: now - 8 * 24 * 60 * 60 * 1000 }, now), true);
  assert.equal(isFilterCacheStale({ updatedAt: now - 2 * 24 * 60 * 60 * 1000 }, now), false);
});

test('reserves the visible side panel so the page cannot cover it', () => {
  const { page } = calculateViewBounds({ width: 1200, height: 800, showBookmarks: true, privateMode: false, sidebarVisible: true, panelVisible: false, overlay: false });
  assert.deepEqual(page, { x: 270, y: 160, width: 930, height: 640 });
});

test('hides website views behind dialogs and prompts', () => {
  const { page, panel } = calculateViewBounds({ width: 1200, height: 800, showBookmarks: true, privateMode: false, sidebarVisible: false, panelVisible: true, overlay: true });
  assert.equal(page.height, 0);
  assert.equal(panel.height, 0);
});

test('keeps the website below the shortened chrome when bookmarks are hidden', () => {
  const { page } = calculateViewBounds({ width: 1200, height: 800, showBookmarks: false, privateMode: false, sidebarVisible: false, panelVisible: false, overlay: false });
  assert.equal(page.y, 126);
  assert.equal(page.height, 674);
});
