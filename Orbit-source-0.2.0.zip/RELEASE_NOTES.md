## Orbit 0.2.0 preview release

This is an experimental release. macOS packages are signed and notarized only when the repository has valid Apple Developer ID and App Store Connect secrets configured. Without those secrets, macOS packages remain unsigned.

Packages are built on native GitHub-hosted runners for macOS, Windows, and Linux. Windows and Linux downloads are preview packages and may require system libraries provided by the target distribution. Browser extensions, cross-device sync, and a password manager are not included.

Orbit has not received an independent security audit. Automated tests and scans do not certify browser security. The optional Ghostery-based content blocker uses third-party filter lists and can miss ads or trackers.
