const path = require('node:path');

const packagerConfig = {
    name: 'Orbit',
    appBundleId: 'studio.orbit.browser',
    asar: true,
    ignore: [/^\/outputs(?:\/|$)/, /^\/work(?:\/|$)/, /^\/out(?:\/|$)/],
    download: { cacheRoot: path.join(__dirname, 'work', 'electron-cache') }
};

// These settings are applied only when the release workflow has installed the
// owner's Developer ID certificate and App Store Connect API credentials.
if (process.env.CSC_NAME) {
  packagerConfig.osxSign = { identity: process.env.CSC_NAME };
  if (process.env.APPLE_API_KEY_PATH && process.env.APPLE_API_KEY_ID && process.env.APPLE_API_ISSUER) {
    packagerConfig.osxNotarize = {
      appleApiKey: process.env.APPLE_API_KEY_PATH,
      appleApiKeyId: process.env.APPLE_API_KEY_ID,
      appleApiIssuer: process.env.APPLE_API_ISSUER
    };
  }
}

module.exports = {
  packagerConfig,
  rebuildConfig: {},
  // The host runner creates its native ZIP. This keeps each OS build native,
  // which is required for signing and avoids fragile cross-platform packaging.
  makers: [{ name: '@electron-forge/maker-zip' }]
};
