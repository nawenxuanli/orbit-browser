const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('orbit', {
  command: (action, value) => ipcRenderer.invoke('browser:command', action, value),
  on: (channel, callback) => {
    const allowed = ['browser:initial', 'browser:tabs', 'browser:navigation', 'browser:bookmarks', 'browser:history', 'browser:downloads', 'browser:settings', 'browser:permission', 'browser:crash', 'browser:profiles', 'browser:panel-error', 'browser:permission-choices', 'browser:web-panels', 'browser:blocker-status'];
    if (allowed.includes(channel)) ipcRenderer.on(channel, (_event, value) => callback(value));
  }
});
