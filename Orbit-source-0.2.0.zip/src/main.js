const { app, BrowserWindow, WebContentsView, ipcMain, session, shell } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const { pathToFileURL } = require('node:url');
const { ElectronBlocker } = require('@ghostery/adblocker-electron');
const { normalizeUrl, isBlockedTracker, isFilterCacheStale, calculateViewBounds } = require('./browser-utils');

const states = new Map();
const profileData = new Map();
const pendingPermissions = new Map();
const initializedSessions = new WeakSet();
const blockerSessions = new WeakSet();
let blockerEnginePromise;
let profiles = ['Default'];
let nextPrivateId = 1;
const defaults = () => ({ bookmarks: [], history: [], downloads: [], notes: '', webPanels: [], permissionChoices: {}, settings: { theme: 'midnight', blocker: false, showBookmarks: true, toolbar: { history: true, downloads: true, sidePanel: true, privacy: true }, toolbarOrder: ['history','downloads','sidePanel','privacy'], shortcuts: { newTab: 'Meta+T', focusAddress: 'Meta+L', closeTab: 'Meta+W' } } });
const safeName = name => String(name || '').trim().replace(/[^\p{L}\p{N} _-]/gu, '').slice(0, 36);
const profileKey = name => safeName(name).toLowerCase().replace(/\s+/g, '-') || 'default';
const profileFile = name => path.join(app.getPath('userData'), 'profiles', `${profileKey(name)}.json`);
const profilesFile = () => path.join(app.getPath('userData'), 'profiles.json');

function readProfiles() {
  try { const parsed = JSON.parse(fs.readFileSync(profilesFile(), 'utf8')); if (Array.isArray(parsed) && parsed.length) profiles = [...new Set(['Default', ...parsed.map(safeName).filter(Boolean)])]; }
  catch { /* Start with the built-in profile. */ }
}
function writeProfiles() { fs.mkdirSync(app.getPath('userData'), { recursive: true }); fs.writeFileSync(profilesFile(), JSON.stringify(profiles, null, 2)); }
function readProfileData(name) {
  if (profileData.has(name)) return profileData.get(name);
  let stored = {};
  try { stored = JSON.parse(fs.readFileSync(profileFile(name), 'utf8')); }
  catch {
    if (name === 'Default') { try { stored = JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), 'orbit-data.json'), 'utf8')); } catch { /* First run. */ } }
  }
  const base = defaults();
  const data = { ...base, ...stored, settings: { ...base.settings, ...(stored.settings || {}), toolbar: { ...base.settings.toolbar, ...(stored.settings?.toolbar || {}) }, toolbarOrder: Array.isArray(stored.settings?.toolbarOrder) ? stored.settings.toolbarOrder : base.settings.toolbarOrder, shortcuts: { ...base.settings.shortcuts, ...(stored.settings?.shortcuts || {}) } } };
  data.bookmarks ||= []; data.history ||= []; data.downloads ||= []; data.notes ||= ''; data.webPanels ||= []; data.permissionChoices ||= {};
  profileData.set(name, data); return data;
}
function persist(state) {
  if (state.privateMode) return;
  fs.mkdirSync(path.dirname(profileFile(state.profile)), { recursive: true });
  fs.writeFileSync(profileFile(state.profile), JSON.stringify(state.data, null, 2));
}
function send(state, channel, payload) { if (!state.win.isDestroyed()) state.win.webContents.send(channel, payload); }
async function getBlockerEngine() {
  if (!blockerEnginePromise) {
    const cachePath = path.join(app.getPath('userData'), 'filter-engine.bin');
    const cacheMetaPath = `${cachePath}.meta.json`;
    const backupPath = `${cachePath}.stale-backup`;
    fs.mkdirSync(path.dirname(cachePath), { recursive: true });
    const cacheIsStale = (() => {
      try {
        const meta = JSON.parse(fs.readFileSync(cacheMetaPath, 'utf8'));
        return isFilterCacheStale(meta);
      } catch { return fs.existsSync(cachePath); }
    })();
    let hasBackup = false;
    if (cacheIsStale && fs.existsSync(cachePath)) {
      try { fs.rmSync(backupPath, { force: true }); fs.renameSync(cachePath, backupPath); hasBackup = true; } catch { /* Keep using the available cache. */ }
    }
    blockerEnginePromise = ElectronBlocker.fromPrebuiltAdsAndTracking(globalThis.fetch, {
      path: cachePath,
      read: file => fs.promises.readFile(file),
      write: (file, bytes) => fs.promises.writeFile(file, bytes)
    }).then(engine => {
      fs.writeFileSync(cacheMetaPath, JSON.stringify({ updatedAt: Date.now() }));
      if (hasBackup) fs.rmSync(backupPath, { force: true });
      return engine;
    }).catch(error => {
      // A failed refresh must not discard the last known working filters.
      if (hasBackup && fs.existsSync(backupPath)) {
        fs.rmSync(cachePath, { force: true });
        fs.renameSync(backupPath, cachePath);
      }
      blockerEnginePromise = null;
      throw error;
    });
  }
  return blockerEnginePromise;
}
async function setSessionBlocker(state, enabled) {
  if (!enabled) {
    if (blockerSessions.has(state.session)) {
      try { const engine = await getBlockerEngine(); engine.disableBlockingInSession(state.session); } catch { /* Nothing was installed. */ }
      blockerSessions.delete(state.session);
    }
    state.blockerReady = true; state.blockerError = null;
    send(state, 'browser:blocker-status', { enabled: false, ready: true });
    return;
  }
  state.blockerReady = false; state.blockerError = null;
  send(state, 'browser:blocker-status', { enabled: true, ready: false });
  try {
    const engine = await getBlockerEngine();
    if (!state.win.isDestroyed() && state.data.settings.blocker) {
      engine.enableBlockingInSession(state.session);
      blockerSessions.add(state.session);
      state.blockerReady = true;
      send(state, 'browser:blocker-status', { enabled: true, ready: true });
    }
  } catch (error) {
    state.blockerReady = false; state.blockerError = error.message;
    send(state, 'browser:blocker-status', { enabled: true, ready: false, error: error.message });
  }
}
function ownerFor(sessionRef, wc) {
  return [...states.values()].find(candidate => candidate.session === sessionRef && ([...candidate.tabs.values()].some(tab => tab.view.webContents === wc) || candidate.panelView?.webContents === wc));
}
function tabInfo(id, item) {
  const url = item.view.webContents.getURL();
  return { id, title: url.endsWith('/src/newtab.html') ? 'New tab' : item.view.webContents.getTitle() || 'New tab', url: url.endsWith('/src/newtab.html') ? '' : url, loading: item.view.webContents.isLoading(), pinned: item.pinned, group: item.group, privateMode: item.privateMode };
}
function broadcastTabs(state) { send(state, 'browser:tabs', { tabs: [...state.tabs].map(([id, item]) => tabInfo(id, item)), activeId: state.activeId }); }
function updateBounds(state) {
  if (!state || state.win.isDestroyed() || !state.activeId || !state.tabs.has(state.activeId)) return;
  const { width, height } = state.win.getContentBounds();
  const bounds = calculateViewBounds({ width, height, showBookmarks: state.data.settings.showBookmarks, privateMode: state.privateMode, sidebarVisible: state.sidebarVisible, panelVisible: state.panelVisible, overlay: state.chromeOverlay });
  state.tabs.get(state.activeId).view.setBounds(bounds.page);
  if (state.panelView && bounds.panel) state.panelView.setBounds(bounds.panel);
}
function switchTab(state, id) {
  if (!state.tabs.has(id)) return;
  if (state.activeId && state.tabs.has(state.activeId)) state.win.contentView.removeChildView(state.tabs.get(state.activeId).view);
  state.activeId = id;
  state.win.contentView.addChildView(state.tabs.get(id).view);
  if (state.panelView && state.panelVisible) state.win.contentView.addChildView(state.panelView);
  updateBounds(state); broadcastTabs(state);
}
function addHistory(state, url, title) {
  if (state.privateMode || !/^https?:/i.test(url)) return;
  state.data.history.unshift({ url, title: title || url, visitedAt: Date.now() });
  state.data.history = state.data.history.slice(0, 500); persist(state);
}
function installSessionHandlers(state) {
  if (initializedSessions.has(state.session)) return;
  initializedSessions.add(state.session);
  state.session.setPermissionRequestHandler((wc, permission, callback, details) => {
    if (wc.isDestroyed()) { callback(false); return; }
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const timeout = setTimeout(() => { if (pendingPermissions.has(id)) { pendingPermissions.delete(id); callback(false); } }, 30000);
    const owner = ownerFor(state.session, wc);
    pendingPermissions.set(id, { owner, origin: '', permission, resolve: allow => { clearTimeout(timeout); callback(allow); } });
    let origin = 'Unknown site';
    try { origin = new URL(details.requestingUrl || wc.getURL()).origin; } catch { /* Keep the label. */ }
    pendingPermissions.get(id).origin = origin;
    const saved = state.data.permissionChoices?.[`${origin}|${permission}`];
    if (saved === 'allow' || saved === 'deny') { clearTimeout(timeout); pendingPermissions.delete(id); callback(saved === 'allow'); return; }
    send(owner || state, 'browser:permission', { id, origin, permission });
  });
  state.session.webRequest.onBeforeRequest({ urls: ['*://*/*'] }, (details, callback) => {
    let blocked = false;
    if (!blockerSessions.has(state.session) && state.data.settings.blocker) { try { blocked = isBlockedTracker(new URL(details.url).hostname); } catch { /* Let Chromium handle it. */ } }
    callback({ cancel: blocked });
  });
  state.session.on('will-download', (_event, item, wc) => {
    const owner = ownerFor(state.session, wc) || state;
    const entry = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, filename: item.getFilename(), url: item.getURL(), path: item.getSavePath(), state: 'inProgress', received: 0, total: item.getTotalBytes(), startedAt: Date.now() };
    owner.data.downloads.unshift(entry);
    const publish = () => { entry.received = item.getReceivedBytes(); entry.total = item.getTotalBytes(); send(owner, 'browser:downloads', owner.data.downloads); };
    item.on('updated', (_e, status) => { entry.state = status; publish(); });
    item.once('done', (_e, status) => { entry.state = status; entry.path = item.getSavePath(); entry.finishedAt = Date.now(); publish(); persist(owner); });
    publish();
  });
}
function createView(state, url, isPanel = false) {
  const view = new WebContentsView({ webPreferences: { session: state.session, contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true, spellcheck: true } });
  view.webContents.setWindowOpenHandler(({ url: target }) => { createTab(state, target); return { action: 'deny' }; });
  const startPage = pathToFileURL(path.join(__dirname, 'newtab.html')).href;
  view.webContents.on('will-navigate', (event, target) => { if (!/^https?:/i.test(target) && target !== startPage) event.preventDefault(); });
  const notifyNavigation = currentUrl => {
    if (!isPanel) addHistory(state, currentUrl, view.webContents.getTitle());
    send(state, 'browser:navigation', { id: isPanel ? 'panel' : [...state.tabs].find(([, item]) => item.view === view)?.[0], url: currentUrl === startPage ? '' : currentUrl, title: view.webContents.getTitle() });
  };
  view.webContents.on('did-navigate', (_e, currentUrl) => notifyNavigation(currentUrl));
  view.webContents.on('did-navigate-in-page', (_e, currentUrl) => notifyNavigation(currentUrl));
  view.webContents.on('did-fail-load', (_event, errorCode, errorDescription, validatedURL, isMainFrame) => {
    if (isPanel && isMainFrame && errorCode !== -3) send(state, 'browser:panel-error', { errorCode, errorDescription, url: validatedURL });
  });
  view.webContents.on('page-title-updated', () => broadcastTabs(state));
  view.webContents.on('did-start-loading', () => broadcastTabs(state));
  view.webContents.on('did-stop-loading', () => broadcastTabs(state));
  view.webContents.on('render-process-gone', () => send(state, 'browser:crash', { id: isPanel ? 'panel' : [...state.tabs].find(([, item]) => item.view === view)?.[0] }));
  if (url === 'orbit:newtab') view.webContents.loadFile(path.join(__dirname, 'newtab.html'));
  else view.webContents.loadURL(normalizeUrl(url));
  return view;
}
function createTab(state, url = 'orbit:newtab') {
  const id = String(state.nextId++);
  const view = createView(state, url);
  state.tabs.set(id, { view, pinned: false, group: null, privateMode: state.privateMode });
  switchTab(state, id); return id;
}
function createBrowserWindow({ profile = 'Default', privateMode = false } = {}) {
  const win = new BrowserWindow({ width: 1320, height: 860, minWidth: 840, minHeight: 600, title: privateMode ? 'Orbit — Private' : `Orbit — ${profile}`, backgroundColor: '#0b1118', webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  const rendererId = win.webContents.id;
  const baseData = privateMode ? readProfileData(profile) : readProfileData(profile);
  const data = privateMode ? { ...defaults(), settings: { ...baseData.settings, shortcuts: { ...baseData.settings.shortcuts } } } : baseData;
  const state = { win, profile, privateMode, data, session: privateMode ? session.fromPartition(`orbit-private-${nextPrivateId++}`, { cache: false }) : session.fromPartition(`persist:orbit-${profileKey(profile)}`), tabs: new Map(), activeId: null, nextId: 1, panelView: null, panelVisible: false, sidebarVisible: false, chromeOverlay: false, blockerReady: !data.settings.blocker, blockerError: null };
  states.set(rendererId, state);
  installSessionHandlers(state);
  if (data.settings.blocker) setSessionBlocker(state, true);
  win.loadFile(path.join(__dirname, 'index.html'));
  win.on('resize', () => updateBounds(state));
  win.on('closed', () => { for (const item of state.tabs.values()) if (!item.view.webContents.isDestroyed()) item.view.webContents.close(); if(state.panelView&&!state.panelView.webContents.isDestroyed())state.panelView.webContents.close(); states.delete(rendererId); });
  win.webContents.on('did-finish-load', () => { send(state, 'browser:initial', { bookmarks: state.privateMode ? [] : data.bookmarks, webPanels: state.privateMode ? [] : data.webPanels, settings: data.settings, history: state.privateMode ? [] : data.history.slice(0, 100), notes: state.privateMode ? '' : data.notes || '', privateMode, profile, profiles, blockerReady: state.blockerReady, blockerError: state.blockerError }); createTab(state); });
  return state;
}
function createProfile(name) {
  const clean = safeName(name);
  if (!clean || profiles.some(item => item.toLowerCase() === clean.toLowerCase())) return null;
  profiles.push(clean); writeProfiles(); return clean;
}

app.whenReady().then(() => {
  readProfiles();
  createBrowserWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createBrowserWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('browser:command', async (event, action, value) => {
  const state = states.get(event.sender.id);
  if (!state) return null;
  const current = state.tabs.get(state.activeId)?.view.webContents;
  switch (action) {
    case 'navigate': current?.loadURL(normalizeUrl(value)); break;
    case 'new-tab': createTab(state, value || undefined); break;
    case 'new-private-window': createBrowserWindow({ profile: state.profile, privateMode: true }); break;
    case 'new-profile': { const name = createProfile(value); if (name) createBrowserWindow({ profile: name }); break; }
    case 'switch-profile': if (!state.privateMode && profiles.includes(value)) createBrowserWindow({ profile: value }); break;
    case 'close-tab': if (state.tabs.size > 1 && state.tabs.has(String(value))) { const id=String(value);const wasActive=id===state.activeId;state.tabs.get(id).view.webContents.close();state.tabs.delete(id);if(wasActive)switchTab(state,[...state.tabs.keys()][0]);else broadcastTabs(state); } break;
    case 'switch-tab': switchTab(state, String(value)); break;
    case 'set-pinned': if (state.tabs.has(String(value?.id))) { state.tabs.get(String(value.id)).pinned=Boolean(value.pinned);broadcastTabs(state); } break;
    case 'set-group': if (state.tabs.has(String(value?.id))) { state.tabs.get(String(value.id)).group=typeof value.group==='string'?value.group.slice(0,40):null;broadcastTabs(state); } break;
    case 'back': if (current?.navigationHistory.canGoBack()) current.navigationHistory.goBack(); break;
    case 'forward': if (current?.navigationHistory.canGoForward()) current.navigationHistory.goForward(); break;
    case 'reload': current?.reload(); break;
    case 'bookmark-add': { const url=current?.getURL();if(!state.privateMode&&url&&!state.data.bookmarks.some(b=>b.url===url)){state.data.bookmarks.push({title:current.getTitle()||url,url});persist(state);send(state,'browser:bookmarks',state.data.bookmarks);}break; }
    case 'bookmark-open': createTab(state, value); break;
    case 'bookmark-remove': if(!state.privateMode){state.data.bookmarks=state.data.bookmarks.filter(b=>b.url!==value);persist(state);send(state,'browser:bookmarks',state.data.bookmarks);}break;
    case 'get-history': send(state,'browser:history',state.privateMode?[]:state.data.history.slice(0,100)); break;
    case 'clear-history': if(!state.privateMode){state.data.history=[];persist(state);send(state,'browser:history',[]);}break;
    case 'permission-choices': send(state,'browser:permission-choices',state.privateMode?[]:Object.entries(state.data.permissionChoices||{}).map(([key,choice])=>({key,choice})));break;
    case 'clear-permission-choices': if(!state.privateMode){state.data.permissionChoices={};persist(state);send(state,'browser:permission-choices',[]);}break;
    case 'save-web-panel': if(!state.privateMode){const name=String(value?.name||'').trim().slice(0,50);const url=normalizeUrl(value?.url);if(name&&/^https?:/i.test(url)){state.data.webPanels=state.data.webPanels||[];const prior=state.data.webPanels.findIndex(panel=>panel.url===url);const panel={name,url};if(prior>=0)state.data.webPanels[prior]=panel;else state.data.webPanels.push(panel);persist(state);send(state,'browser:web-panels',state.data.webPanels);}}break;
    case 'remove-web-panel': if(!state.privateMode){state.data.webPanels=(state.data.webPanels||[]).filter(panel=>panel.url!==value);persist(state);send(state,'browser:web-panels',state.data.webPanels);}break;
    case 'get-web-panels': send(state,'browser:web-panels',state.privateMode?[]:state.data.webPanels||[]);break;
    case 'get-downloads': send(state,'browser:downloads',state.data.downloads||[]); break;
    case 'save-note': if(!state.privateMode){state.data.notes=String(value||'').slice(0,20000);persist(state);}break;
    case 'set-sidebar': state.sidebarVisible=Boolean(value)&&!state.panelVisible;updateBounds(state);break;
    case 'chrome-overlay': state.chromeOverlay=Boolean(value);updateBounds(state);break;
    case 'save-settings': state.data.settings={...state.data.settings,...value,toolbar:{...state.data.settings.toolbar,...(value?.toolbar||{})},toolbarOrder:Array.isArray(value?.toolbarOrder)?value.toolbarOrder:state.data.settings.toolbarOrder,shortcuts:{...state.data.settings.shortcuts,...(value?.shortcuts||{})}};persist(state);updateBounds(state);send(state,'browser:settings',state.data.settings);if(Object.hasOwn(value||{},'blocker'))setSessionBlocker(state,Boolean(state.data.settings.blocker));break;
    case 'permission': { const pending=pendingPermissions.get(value?.id);if(pending?.owner===state){if(value.remember&&!state.privateMode){state.data.permissionChoices ||= {};state.data.permissionChoices[`${pending.origin}|${pending.permission}`]=value.allow?'allow':'deny';persist(state);}pending.resolve(Boolean(value.allow));}pendingPermissions.delete(value?.id);break; }
    case 'web-panel': if (value?.open) { state.sidebarVisible=false;if(!state.panelView)state.panelView=createView(state,value.url||'https://duckduckgo.com',true);else state.panelView.webContents.loadURL(normalizeUrl(value.url||'https://duckduckgo.com'));state.panelVisible=true;state.win.contentView.addChildView(state.panelView);updateBounds(state); } else { state.panelVisible=false;if(state.panelView){state.win.contentView.removeChildView(state.panelView);state.panelView.webContents.close();state.panelView=null;}updateBounds(state); }break;
    case 'show-profiles': send(state,'browser:profiles',{profiles,active:state.profile,privateMode:state.privateMode});break;
    case 'show-in-folder': { const entry=state.data.downloads.find(item=>item.id===value);if(entry?.path)shell.showItemInFolder(entry.path);break; }
  }
  return true;
});
