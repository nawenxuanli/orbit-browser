function normalizeUrl(input) {
  const value = String(input || '').trim();
  if (!value) return 'https://duckduckgo.com';
  if (/^https?:\/\//i.test(value)) return value;
  if (/^[\w-]+\.[\w.-]+(?::\d+)?(?:\/.*)?$/.test(value)) return `https://${value}`;
  return `https://duckduckgo.com/?q=${encodeURIComponent(value)}`;
}
const trackerHosts = new Set(['doubleclick.net','googlesyndication.com','googletagmanager.com','google-analytics.com','amazon-adsystem.com','scorecardresearch.com','connect.facebook.net']);
function isBlockedTracker(host) {
  const normalized = String(host || '').toLowerCase().replace(/\.$/, '');
  return [...trackerHosts].some(domain => normalized === domain || normalized.endsWith(`.${domain}`));
}
function calculateViewBounds({ width, height, showBookmarks, privateMode, sidebarVisible, panelVisible, overlay }) {
  const top = showBookmarks && !privateMode ? 160 : 126;
  const panelWidth = panelVisible ? Math.min(360, Math.floor(width * 0.38)) : 0;
  const sidebarWidth = sidebarVisible && !panelVisible ? 270 : 0;
  const viewHeight = overlay ? 0 : Math.max(0, height - top);
  return {
    page: { x: sidebarWidth, y: top, width: Math.max(0, width - sidebarWidth - panelWidth), height: viewHeight },
    panel: panelVisible ? { x: width - panelWidth, y: top, width: panelWidth, height: viewHeight } : null
  };
}
module.exports = { normalizeUrl, isBlockedTracker, calculateViewBounds };
