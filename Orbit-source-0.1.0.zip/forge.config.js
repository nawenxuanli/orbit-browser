const path = require('node:path');

module.exports = {
  packagerConfig: {
    name: 'Orbit',
    appBundleId: 'studio.orbit.browser',
    asar: true,
    ignore: [/^\/outputs(?:\/|$)/, /^\/work(?:\/|$)/, /^\/out(?:\/|$)/],
    download: { cacheRoot: path.join(__dirname, 'work', 'electron-cache') }
  },
  rebuildConfig: {},
  makers: [
    { name: '@electron-forge/maker-zip', platforms: ['darwin'] }
  ]
};
